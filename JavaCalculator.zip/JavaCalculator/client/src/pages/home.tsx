import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Heart } from "lucide-react";

interface Pet {
  name: string;
  imageUrl: string;
  description: string;
}

const petData: Record<string, Pet> = {
  bird: {
    name: 'Bird',
    imageUrl: 'https://images.unsplash.com/photo-1444464666168-49d633b86797?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    description: 'A beautiful feathered friend'
  },
  cat: {
    name: 'Cat',
    imageUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    description: 'A curious and independent companion'
  },
  dog: {
    name: 'Dog',
    imageUrl: 'https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    description: 'A loyal and playful friend'
  },
  rabbit: {
    name: 'Rabbit',
    imageUrl: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    description: 'A gentle and quiet companion'
  },
  pig: {
    name: 'Pig',
    imageUrl: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400',
    description: 'A friendly farm animal'
  }
};

export default function Home() {
  const [selectedPet, setSelectedPet] = useState<string>("pig");

  const currentPet = petData[selectedPet];

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-2xl mx-auto">
        {/* Window-like container */}
        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg overflow-hidden">
          {/* Title bar */}
          <div className="bg-blue-600 text-white px-4 py-2 flex items-center">
            <div className="w-4 h-4 bg-yellow-400 rounded-full mr-2"></div>
            <span className="font-medium">RadioButtonDemo</span>
          </div>

          {/* Content area */}
          <div className="p-8 bg-gray-50">
            <div className="flex gap-8">
              {/* Radio buttons section */}
              <div className="flex-1">
                <RadioGroup 
                  value={selectedPet} 
                  onValueChange={setSelectedPet}
                  className="space-y-4"
                >
                  {Object.entries(petData).map(([key, pet]) => (
                    <div key={key} className="flex items-center">
                      <RadioGroupItem 
                        value={key} 
                        id={key} 
                        className="border-2 border-gray-400 w-5 h-5"
                      />
                      <Label 
                        htmlFor={key} 
                        className="ml-3 text-gray-800 font-medium cursor-pointer text-lg"
                      >
                        {pet.name}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Image display area */}
              <div className="flex-1 flex items-center justify-center">
                <img 
                  src={currentPet.imageUrl}
                  alt={currentPet.name}
                  className="max-w-full max-h-64 object-contain"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjE1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjNmNGY2IiBzdHJva2U9IiNkMWQ1ZGIiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjNjQ3NDhiIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+SW1hZ2U8L3RleHQ+PC9zdmc+';
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
