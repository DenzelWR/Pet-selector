# Pet Selector Application

## Overview

This is a modern React-based web application built with Express.js backend that demonstrates an interactive pet selector interface. The application allows users to select different pets using radio buttons and displays corresponding images and descriptions dynamically. It's built using a full-stack TypeScript architecture with modern tooling and UI components.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks for local state, TanStack Query for server state
- **UI Library**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Component Structure**: Atomic design pattern with reusable UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution in development
- **Build**: esbuild for fast production bundling
- **Storage**: In-memory storage with interface-based design for easy database migration

### Database Layer
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: Located in shared directory for type safety across frontend/backend
- **Migrations**: Managed through drizzle-kit
- **Connection**: Neon Database serverless driver

## Key Components

### Frontend Components
- **Pet Selector Interface**: Interactive radio button group for pet selection
- **Dynamic Image Display**: Responsive image rendering with loading states
- **UI Components**: Complete shadcn/ui component library including cards, buttons, radio groups, and form elements
- **Routing**: Home page with 404 handling
- **Toast Notifications**: User feedback system using Radix UI toast primitives

### Backend Components
- **Express Server**: RESTful API structure with middleware for logging and error handling
- **Route System**: Modular route registration with `/api` prefix convention
- **Storage Interface**: Abstracted storage layer with CRUD operations for users
- **Development Integration**: Vite middleware integration for seamless development experience

### Shared Components
- **Database Schema**: Type-safe schema definitions with Zod validation
- **Type Definitions**: Shared TypeScript types for consistent data structures

## Data Flow

1. **User Interaction**: User selects a pet via radio button interface
2. **State Update**: React state updates trigger re-render with loading indicator
3. **Image Loading**: New pet image loads with simulated delay for better UX
4. **Display Update**: Pet information (name, image, description) updates dynamically
5. **API Communication**: Prepared for future backend integration via TanStack Query

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Query for data fetching
- **UI Framework**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Database**: Drizzle ORM with Neon serverless PostgreSQL driver
- **Development**: Vite, TypeScript, esbuild for tooling

### Utility Libraries
- **Date Handling**: date-fns for date manipulation
- **Form Management**: React Hook Form with Zod resolvers
- **Image Sources**: Unsplash for high-quality pet images
- **Icons**: Lucide React for consistent iconography

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite development server with HMR
- **TypeScript Checking**: Real-time type checking with TSC
- **Database Push**: Direct schema synchronization via drizzle-kit
- **Error Handling**: Runtime error overlay for development debugging

### Production Build
- **Frontend**: Vite production build with optimized assets
- **Backend**: esbuild bundling for Node.js deployment
- **Database**: Migration-based deployment with PostgreSQL
- **Serving**: Express serves both API routes and static frontend assets

### Environment Configuration
- **Database**: Requires `DATABASE_URL` environment variable
- **Build Targets**: Separate client and server build processes
- **Asset Management**: Optimized asset bundling and serving

## Changelog
- June 30, 2025. Initial setup

## User Preferences
Preferred communication style: Simple, everyday language.