# Pet Selector Application

A modern web-based pet selector application that recreates the functionality of a Java desktop application using React and TypeScript. Users can select different pets using radio buttons and see corresponding images displayed dynamically.

## Features

- **Interactive Radio Buttons**: Five pet options (Bird, Cat, Dog, Rabbit, Pig)
- **Dynamic Image Display**: Images change based on radio button selection
- **Modern UI**: Clean, responsive design with loading animations
- **TypeScript**: Full type safety across the application
- **Responsive Design**: Works on desktop and mobile devices

## Technologies Used

### Frontend
- React 18 with TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- Radix UI for accessible components
- Wouter for routing
- TanStack Query for data management

### Backend
- Node.js with Express
- TypeScript
- Drizzle ORM (configured for PostgreSQL)
- In-memory storage

## Getting Started

### Prerequisites
- Node.js 20 or higher
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd pet-selector-app
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── lib/            # Utility functions
│   │   └── hooks/          # Custom React hooks
├── server/                 # Backend Express application
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   └── storage.ts         # Data storage interface
├── shared/                 # Shared types and schemas
└── components.json         # shadcn/ui configuration
```

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally

## Demo

The application displays a radio button interface where users can select from five different pets:
- Bird
- Cat  
- Dog
- Rabbit
- Pig

When a pet is selected, the corresponding image is displayed with a smooth loading animation.

## Original Design

This application recreates the functionality of a Java Swing desktop application that used radio buttons for pet selection. The web version maintains the same core functionality while providing a modern, responsive user interface.

## License

MIT License - see LICENSE file for details